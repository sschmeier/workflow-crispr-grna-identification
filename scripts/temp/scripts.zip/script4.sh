
#!/bin/bash

find . -
